# HD38880 speech frame format — SOLVED (Vanguard SK6 ROMs)

Derived from sk6_ic07/08/11.bin (CRCs 2b7cbae9 / 3b7e9d7c / c36df041, all matching MAME),
mapped to 0x4000-0x57FF, using the 16 known ADSET phrase addresses as alignment anchors.

## The format

**Bit packing: LSB-first within each byte. Fields are also LSB-first.**
**Physical frame = 49 bits = 48 parameter bits + 1 control bit.**

| Bit offset | Width | Field | Evidence |
|---|---|---|---|
| 0–5   | 6 | **Amp** (amplitude/energy) | Starts near 0 at every phrase onset and ramps smoothly — a classic attack envelope |
| 6     | 1 | **Control flag** (probably Repeat) | Set in 18.1% of frames; histogram discontinuity at 64 proves it is NOT the Amp MSB |
| 7–12  | 6 | **Pitch** (period in samples; 0 = unvoiced) | Slowly varying, mode 40–47; 0 in 10.6% of frames = unvoiced |
| 13–19 | 7 | **k1** (tanh⁻¹ companded) | Smooth trajectory centred near mid-scale |
| 20–24 | 5 | **k2** (tanh⁻¹ companded) | Smooth, centred near mid-scale |
| 25–27 | 3 | k3 | |
| 28–30 | 3 | k4 | |
| 31–33 | 3 | k5 | |
| 34–36 | 3 | k6 | |
| 37–39 | 3 | k7 | |
| 40–42 | 3 | k8 | |
| 43–45 | 3 | k9 | |
| 46–48 | 3 | k10 | |

Parameter bits: 6 + 6 + 7 + 5 + (8 x 3) = **48** — exactly the figure in Hitachi's
published table. Plus the 1 control bit = 49 bits physically per frame.
At 20 ms/frame that is 2.4 kbps of parameters, matching the documented rate.

Pitch range: values ~20–48 at 8 kHz sampling = 167–400 Hz, consistent with the
game's synthetic voice; pitch = 0 selects the M-sequence (unvoiced) source.

## How it was found

1. **Frame period by bit-agreement autocorrelation.** Adjacent LPC frames are similar,
   so bits separated by one frame agree more often than chance. Sweeping the lag over
   all 16 phrases gives a sharp peak: agreement 0.681 at lag 49 bits against a 0.505
   baseline, with clean harmonics at 98 and 147. LSB-first scores higher than MSB-first
   (0.681 vs 0.660), and the underlying physical relation is "bit n of byte B correlates
   with bit n+1 of byte B+6" — i.e. frames slip one bit per frame relative to the byte
   grid. **That is why phrase lengths are not multiples of 6 bytes**, which is what made
   the format look variable-length in the earlier analysis.

2. **Field boundaries by per-position agreement.** Within the 49-bit grid, a field stored
   LSB-first shows low agreement at its LSB (noisy) rising to high agreement at its MSB
   (slowly varying). Sharp drops therefore mark field starts. The profile shows drops at
   0, 7, 13, 20, 25, 28, 31, 34, 37, 40, 43, 46 — **twelve fields**, and the last eight are
   a perfect 3-bit repeating pattern. Twelve fields is exactly Amp + Pitch + k1..k10.

3. **Field identification by decoding.** Field 1 ramps from near zero at every phrase start
   (amplitude). Field 2 is slowly varying with a zero code appearing 10.6% of the time
   (pitch with unvoiced flag). The 3-bit group is clearly k3..k10; the 7-bit and 5-bit
   fields are k1 and k2 by the standard decreasing-precision convention.

4. **Bit 6 separated from Amp.** The 7-bit reading of bits 0–6 gives a histogram with a
   sharp cliff at 64 (141 frames in 56–63, only 8 in 64–71), while the low-6-bit histogram
   is smooth and unimodal. Bit 6 is therefore an independent flag, and its 18% set rate
   fits a repeat flag (INT2 bit 1 enables repeat).

## Still open

- **Phrase termination.** Frames appear fixed-length throughout, so the trailing 0xFF byte
  at the end of 13 of 16 phrases (0xFE on two more) is probably a stop marker, but the
  leftover bit counts at phrase ends do not yet fit a single clean rule. There may be a
  few bytes of slack between phrases. Note the ROM's last programmed byte is 0x5604 —
  everything from 0x5605 to 0x57FF is unprogrammed 0xFF fill, so phrase 15 is 311 bytes,
  not 818 as a naive "runs to end of ROM" assumption gives.
- **Exact meaning of bit 6.** Repeat is the best fit, but interpolation-inhibit or a
  source/waveform flag are not excluded.
- **Quantiser tables.** k3..k10 are documented as linear, so those need only a full-scale
  range (very likely +/-1 across the 3-bit code). Amp is log-companded and k1/k2 are
  tanh⁻¹-companded; those tables are in the chip's decode ROM and must be fitted
  numerically against the reference recordings.
- **Sign convention** for k1..k10 (offset-binary vs two's complement) — mid-scale-centred
  trajectories suggest offset binary.

## Recommended next step

Feed the decoded parameter stream into parcor_lattice.v (or a Python model of it) with a
first-guess mapping: Amp -> linear or log gain, Pitch -> period in samples, k = (code - mid)
/ mid scaled to +/-1. Then fit the three companding curves by minimising error against
MAME's vg_voi-*.wav, which are recordings of the real chip. Because the field layout is
now fixed, this is a small parameter-fitting problem rather than a search.

---

# Part 2 — Validation against the real chip (MAME vg_voi-*.wav)

The MAME samples are recordings of real HD38880 hardware, so they are ground truth.
Six phrases (1, 5, 6, 8, 10, 13) aligned to the decoded frames with envelope
correlation > 0.6 and were used for fitting.

## Confirmed by the recordings

| Claim | Evidence |
|---|---|
| **Frame period is 20 ms (160 samples @ 8 kHz)** | Solving for the hop that best matches the decoded amplitude track to the reference energy envelope gives 158, 158, 160, 162 on the four best-aligned phrases. Matches the documented value. |
| **Bits 0–5 are amplitude** | corr(code, log RMS of the real recording) = **0.906** |
| **Bits 13–19 are k1** | corr(code, measured reflection coefficient) = **−0.77** |
| **The encoder analysed a pre-emphasised signal** | Applying 1 − 0.9·z⁻¹ before LPC raises mean \|corr\| across k1..k10 from 0.168 to 0.304, and k1 from −0.55 to −0.77. This is exactly the differentiate-on-analysis / integrate-on-synthesis scheme the Hitachi paper describes. |
| **Codes run in descending order** | Every one of k1..k9 correlates negatively. Higher code = more negative coefficient. |
| **Phrase durations** | Decoded vs reference: 0.90/0.906 s, 1.06/1.057 s, 0.84/0.813 s, 1.24/1.329 s etc. |
| **Filter stability** | 100% of decoded frames give poles inside the unit circle; mean F1 527 Hz, F2 1510 Hz — dead centre of real speech. |
| **Bit 6 is a repeat flag** | Frames with bit 6 set show *larger* frame-to-frame coefficient jumps (4.44 vs 2.98), i.e. their stored k-bits are unrelated to their neighbours because they are ignored. |

## Fitted decode curves (first-order approximation of the chip's decode ROM)

    k_m   = slope_m * code + intercept_m        (see hd38880_decode_tables.json)
    amp   : log(rms) = 0.03317 * code + 7.7210
    pitch : period_samples ~= 0.375 * code + 55.7   (weakly constrained, see below)

## Objective result

Synthesis using the recovered format and fitted curves reaches a mean
**log-spectral distortion of 8.4 dB** against the real chip, versus 18.1 dB for
white noise — so roughly half the spectral information is being recovered.
That is well short of a transparent match (a good vocoder is 1–2 dB) but far
beyond chance, and it confirms the field layout carries real spectral content.

## What limits it now, in priority order

1. **Pitch law is unconstrained.** Vanguard's voice is near-monotone: 227 of 241
   usable voiced frames have pitch code 40–47, all mapping to ~72 samples (111 Hz).
   There is almost no dynamic range to fit against. **The Fantasy ROMs and samples
   would likely settle this**, and are the single highest-value next input.
2. **k3–k10 fits are weak** (\|corr\| 0.03–0.53). Only 250 usable frames survive
   alignment and loudness gating. More aligned phrases, sub-frame alignment
   refinement, and joint rather than per-field fitting should all help.
3. **Linear curves are a stand-in for the real tables.** The chip uses tanh⁻¹
   companding on k1/k2 and linear on k3–k10 per Hitachi; fitting the companding
   scale properly (rather than a straight line) should tighten k1/k2 in particular.
4. **Alignment.** Only 6 of 16 phrases aligned well. The reference recordings have
   variable leading silence and possibly SYSPD speed differences.

---

# Part 3 — Independent confirmation on Fantasy, and the pitch law

## The format replicates exactly on a second, unrelated ROM set

Fantasy's speech ROMs (fs_d_7 / fs_e_8 / fs_f_11, CRCs a7ef4cc6 / 19b8fb3e / 3a352e1f)
were analysed blind with the same method:

| | Vanguard | Fantasy |
|---|---|---|
| Best bit period (LSB-first) | 49 bits, agreement **0.681** | 49 bits, agreement **0.712** |
| Detected field boundaries | 0,7,13,20,25,28,31,34,37,40,43,46 | **identical** |
| Last programmed byte | 0x5604 | 0x5654 |

Two different games, different encoders' output, same 49-bit frame and the same
twelve field boundaries. The format is settled.

## Pitch law — solved using Fantasy

Vanguard's voice is near-monotone (pitch codes bunched at 40–47), which is why the
pitch field would not fit from Vanguard alone. Fantasy's speech spans the full code
range (deciles 3 / 21 / 37 / 50 / 61), and combining both datasets gives a clean fit
after octave-error correction and outlier rejection:

    period_samples = 1.4801 * code + 3.055        n = 357, corr = 0.902

That is essentially **period = 1.5 * code + 3**, which suggests the pitch counter is
clocked at two-thirds of the 8 kHz sample rate. Resulting range:

| code | period | F0 |
|---|---|---|
| 10 | 17.9 | 448 Hz |
| 22 | 35.6 | 225 Hz |
| 34 | 53.4 | 150 Hz |
| 46 | 71.1 | 112 Hz |
| 58 | 88.9 | 90 Hz |

pitch code 0 remains the unvoiced (M-sequence) selector.

## Final fitted curves (hd38880_decode_tables.json)

    amp   : log(rms) = 0.04308 * code + 7.2311        corr 0.793
    pitch : period   = 1.4801 * code + 3.055          corr 0.902
    k1    : k = -0.00596*code - 0.2706                corr -0.667
    k2    : k = -0.03239*code + 1.0977                corr -0.539
    k3..k10: see JSON                                 corr -0.14 .. -0.38
    analysis pre-emphasis 1 - 0.9 z^-1 (synthesis de-emphasises)

## Objective result

Log-spectral distortion of the synthesis against the real chip's recordings:

| | LSD | white-noise baseline |
|---|---|---|
| Vanguard | **7.30 dB** | 17.14 dB |
| Fantasy  | **7.38 dB** | 20.19 dB |

Down from 8.38 dB before the Fantasy data was added, and consistent across two
independent games.

## Honest status

Solved: bit order, frame length, all twelve field positions and widths, the amplitude
law, the pitch law, the repeat flag, the pre-emphasis convention, and the sign/ordering
of the coefficient codes.

Not solved: the exact coefficient quantiser tables. k1..k10 are still straight-line
approximations to what Hitachi documents as tanh^-1 companding (k1, k2) and linear
coding (k3..k10), and the k3..k10 correlations (0.14-0.38) are weak enough that most
of the residual 7 dB distortion lives there. The limiting factor is no longer data
volume but analysis method: LPC run on a recording of the chip's *output* is a noisy
estimate of the encoder's *input* coefficients, because the chip's own lossy lattice
(alpha = 0.992), its DAC, the board's analog filtering and the 44.1 kHz sample-rate
conversion all sit in between.

The right next step is **analysis-by-synthesis**: rather than regressing against LPC
estimates, search each quantiser table directly to minimise the spectral distance
between this synthesizer's output and the reference recordings. With only 8 values to
determine per 3-bit field and a good initialisation already in hand, that is a small
optimisation and should recover most of the remaining gap.

---

# Part 4 — Analysis-by-synthesis quantiser tables

Instead of regressing codes against noisy LPC estimates, each quantiser entry was
searched directly to minimise the distance between the model's all-pole envelope
(including the chip's lossy lattice, alpha = 0.992) and the pre-emphasised reference
spectrum, over 577 aligned frames from both games.

Parameterisation: k1 binned to 16 entries (code>>3), k2 to 16 (code>>1), k3..k10 full
8-entry tables — 96 free parameters. Coordinate descent, monotonicity enforced,
75/25 train/test split.

    init      train 5.827  test 6.115 dB
    converged train 4.911  test 5.195 dB

The small train/test gap shows it is generalising rather than memorising.

## Controlled A/B (identical frames, identical alignment)

| | linear fit | analysis-by-synthesis |
|---|---|---|
| Vanguard (n=246) | 4.35 dB | **3.84 dB** |
| Fantasy  (n=305) | 6.05 dB | **5.04 dB** |

## Recovered k1 quantiser (16 bins over the 7-bit code)

    -0.323 -0.342 -0.424 -0.437 -0.485 -0.606 -0.626 -0.667
    -0.707 -0.788 -0.829 -0.869 -0.889 -0.909 -0.930 -0.950

Monotonic, spanning -0.32 to -0.95, with step size compressing toward the extreme —
i.e. uniform in the tanh^-1 domain. **This is the tanh^-1 companding Hitachi documents
for k1/k2, recovered empirically from the ROM data and hardware recordings.** Note the
monotonicity constraint only forbade reversals; it did not impose this shape, and the
unconstrained run produced nearly the same curve.

k3..k10 come out monotonic decreasing over their 8 codes with ranges of roughly
0.2-0.6, consistent with the documented linear coding of the higher coefficients.

Full tables: hd38880_tables_abs.json (loaded automatically by hd38880_decode.py).

## Where the remaining error is

Envelope LSD of 3.8-5.0 dB is a real spectral match but not transparent (1-2 dB).
Remaining contributors, in order:

1. **Frame alignment** is still only +/-half a frame on many phrases, which smears
   every fit. Sub-frame alignment by cross-correlating synthesized against reference
   audio would sharpen all 96 parameters at once.
2. **k2 is the weakest field.** Its fitted curve is nearly flat across the first five
   bins, which suggests the 5-bit code may not be split as assumed, or that k2 shares
   companding with k1 in a way the independent tables cannot capture.
3. **The excitation model is a first approximation.** Impulse vs triangular is
   selected by INT1 bit 3 and Vanguard's actual setting is unknown; the real chip's
   voiced source and the SK6 board's analog output stage are both unmodelled beyond a
   single de-emphasis pole.
4. **Reference chain.** The samples are 44.1 kHz recordings of analog board output,
   downsampled to 8 kHz here.
