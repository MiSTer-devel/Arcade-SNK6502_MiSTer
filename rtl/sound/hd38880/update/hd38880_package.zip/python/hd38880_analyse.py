#!/usr/bin/env python3
"""
HD38880 speech ROM structural analyser (Vanguard / Fantasy, SNK SK6 board).

Findings this tool reproduces:
  * bit order is LSB-first within each byte
  * frame period is 49 bits (frames therefore slip 1 bit per frame vs. bytes,
    which is why phrase lengths are not multiples of 6)
  * the 49 bits split into exactly 12 fields of width 7,6,7,5,3,3,3,3,3,3,3,3
    = 12 parameters, matching Amp + Pitch + k1..k10
Usage:  python3 hd38880_analyse.py <dir-with-sk6_ic07/08/11.bin>
"""
import sys, os
BASE = 0x4000
FRAME = 49
FIELDS = [7, 6, 7, 5, 3, 3, 3, 3, 3, 3, 3, 3]   # derived, see notes
NAMES  = ["F1", "F2", "F3", "F4"] + ["k%d" % i for i in range(3, 11)]
VAN = [0x04000,0x04325,0x044a2,0x045b7,0x046ee,0x04838,0x04984,0x04b01,
       0x04c38,0x04de6,0x04f43,0x05048,0x05160,0x05289,0x0539e,0x054ce]

def load(d):
    img = bytearray()
    for f in ['sk6_ic07.bin', 'sk6_ic08.bin', 'sk6_ic11.bin']:
        img += open(os.path.join(d, f), 'rb').read()
    return img

def bits_lsb(img, s, e):
    out = []
    for a in range(s, e):
        by = img[a - BASE]
        for i in range(8):
            out.append((by >> i) & 1)
    return out

def unpack(b, p):
    """decode one frame at bit position p -> list of field values"""
    vals = []
    for w in FIELDS:
        if p + w > len(b):
            return None
        v = 0
        for i in range(w):
            v |= b[p + i] << i        # fields are LSB-first too
        vals.append(v)
        p += w
    return vals

def rom_end(img):
    """last programmed byte (EPROM tail is 0xff fill)"""
    i = len(img) - 1
    while i > 0 and img[i] == 0xff:
        i -= 1
    return BASE + i + 1

def field_profile(img, bounds, T=FRAME):
    """frame-to-frame agreement per bit position: reveals field boundaries.
       LSB-first fields show LOW agreement at a field's LSB, HIGH at its MSB,
       so a sharp DROP marks a field boundary."""
    agree = [0] * T; cnt = [0] * T
    for i in range(len(bounds) - 1):
        b = bits_lsb(img, bounds[i], bounds[i + 1])
        for f in range((len(b) - T) // T):
            for j in range(T):
                p = f * T + j
                if p + T < len(b):
                    agree[j] += (b[p] == b[p + T]); cnt[j] += 1
    return [agree[j] / cnt[j] for j in range(T)]

def autocorr(img, bounds, lo=30, hi=70):
    best = []
    for T in range(lo, hi):
        m = n = 0
        for i in range(len(bounds) - 1):
            b = bits_lsb(img, bounds[i], bounds[i + 1])
            m += sum(1 for p in range(len(b) - T) if b[p] == b[p + T])
            n += len(b) - T
        best.append((m / n, T))
    return sorted(best, reverse=True)

if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    img = load(d)
    end = rom_end(img)
    bounds = VAN + [end]
    print("speech image 0x%04x-0x%04x, last programmed byte 0x%04x" % (BASE, BASE + len(img), end))
    print("\ntop bit-periods:", ", ".join("%d:%.3f" % (T, v) for v, T in autocorr(img, bounds)[:5]))
    prof = field_profile(img, bounds)
    print("\nper-position agreement (drops = field boundaries):")
    print("  " + " ".join("%.2f" % v for v in prof))
    bnds = [0]
    for w in FIELDS[:-1]:
        bnds.append(bnds[-1] + w)
    print("  assumed field starts:", bnds)
    print("\nfirst 10 frames of each phrase (" + " ".join("%-4s" % n for n in NAMES) + "):")
    for i in range(len(bounds) - 1):
        b = bits_lsb(img, bounds[i], bounds[i + 1])
        print(" phrase %2d" % i)
        for f in range(10):
            v = unpack(b, f * FRAME)
            if v is None: break
            print("   " + " ".join("%-4d" % x for x in v))
