import numpy as np
from py65.devices.mpu6502 import MPU
from py65.disassembler import Disassembler
from py65.memory import ObservableMemory
MAP=[('vg/sk4_ic07.bin',0x4000),('vg/sk4_ic08.bin',0x5000),('vg/sk4_ic09.bin',0x6000),
     ('vg/sk4_ic10.bin',0x7000),('vg/sk4_ic13.bin',0x8000),('vg/sk4_ic14.bin',0x9000),
     ('vg/sk4_ic15.bin',0xa000),('vg/sk4_ic16.bin',0xb000),('vg/sk4_ic13.bin',0xf000)]
mem=bytearray(0x10000)
for f,a in MAP:
    d=open(f,'rb').read(); mem[a:a+len(d)]=d
# find all writes to $3400 (speech port): STA/STX/STY abs = 8D/8E/8C, abs,X=9D
hits=[]
for a in range(0x4000,0xc000):
    op=mem[a]
    if op in (0x8D,0x8E,0x8C,0x9D,0x99) and a+2<0x10000:
        tgt=mem[a+1]|(mem[a+2]<<8)
        if tgt==0x3400: hits.append((a,op))
print("writes to $3400 (speech port):",[hex(a) for a,_ in hits])
print("reset vector: $%04X  IRQ: $%04X  NMI: $%04X"%(
    mem[0xfffc]|(mem[0xfffd]<<8), mem[0xfffe]|(mem[0xffff]<<8), mem[0xfffa]|(mem[0xfffb]<<8)))
mpu=MPU(); mpu.memory=mem
dis=Disassembler(mpu)
def show(start,n,label=''):
    print("\n--- %s $%04X ---"%(label,start))
    pc=start
    for _ in range(n):
        ln,txt=dis.instruction_at(pc)
        print("  $%04X: %-22s %s"%(pc,' '.join('%02X'%mem[pc+i] for i in range(ln)),txt))
        pc+=ln
for a,_ in hits:
    show(max(0x4000,a-40),34,'context before speech write at $%04X'%a)
