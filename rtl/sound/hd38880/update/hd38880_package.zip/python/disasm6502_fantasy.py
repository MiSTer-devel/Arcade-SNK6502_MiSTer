from py65.devices.mpu6502 import MPU
from py65.disassembler import Disassembler
MAP=[('ft/5.12',0x3000),('ft/1.7',0x4000),('ft/2.8',0x5000),('ft/3.9',0x6000),
     ('ft/4.10',0x7000),('ft/ic14.cpu',0x8000),('ft/ic15.cpu',0x9000),
     ('ft/8.16',0xa000),('ft/9.17',0xb000),('ft/ic14.cpu',0xf000)]
mem=bytearray(0x10000)
for f,a in MAP:
    d=open(f,'rb').read(); mem[a:a+len(d)]=d
hits=[]
for a in range(0x3000,0xc000):
    if mem[a] in (0x8D,0x8E,0x8C,0x9D,0x99) and a+2<0x10000:
        if (mem[a+1]|(mem[a+2]<<8))==0x2400: hits.append(a)
print("Fantasy writes to $2400 (speech port):",[hex(a) for a in hits])
mpu=MPU(); mpu.memory=mem
dis=Disassembler(mpu)
def show(start,n,label=''):
    print("\n--- %s $%04X ---"%(label,start))
    pc=start
    for _ in range(n):
        ln,txt=dis.instruction_at(pc)
        print("  $%04X: %-20s %s"%(pc,' '.join('%02X'%mem[pc+i] for i in range(ln)),txt))
        pc+=ln
if hits:
    lo=min(hits); hi=max(hits)
    show(lo-30,int((hi-lo+40)/2.2),'FANTASY SPEECH ROUTINE')
